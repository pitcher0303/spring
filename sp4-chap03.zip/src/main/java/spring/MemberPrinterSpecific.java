package spring;

public class MemberPrinterSpecific extends MemberPrinter{
	int printNum = 0;
	public void print(Member member) {
		this.printNum++;
		System.out.printf("회원정보: 아이디 =%s, 이메일=%s, 이름=%s, 등록일=%tF, 조회수=%d\n", member.getPassword(), member.getEmail(),
				member.getName(), member.getRegisterDate(), this.printNum);
	}
	
	@Override
	public void varargsPrint(String... args) {
		for(String arg : args) {
			System.out.println(arg + "님");
		}
	}
	
}
