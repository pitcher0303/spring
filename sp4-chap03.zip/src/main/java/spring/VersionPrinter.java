package spring;

public class VersionPrinter {
	private int _majorVersion;
	private int _minorVersion;
	
	public VersionPrinter(int majorVersion, int minorVersion) {
		this._majorVersion = majorVersion;
		this._minorVersion = minorVersion;
	}
	
	public void setMajorVersion(int majorVersion) {
		_majorVersion = majorVersion;
	}
	
	public void setMinorVersion(int minorVersion) {
		_minorVersion = minorVersion;
	}
	
	public void print() {
		System.out.printf("이 프로그램의 버전은 %d.%d입니다.\n\n", _majorVersion, _minorVersion);
	}
}
