package spring;

public class IdPasswordNotMatchingException extends RuntimeException {
	
}
