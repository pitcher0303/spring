package spring;

import sample.Client3;

public class Client4 extends Client3{
	public void setHost(String host) {
		System.out.println("Client4.setHost() 실행");
	}
	
	public void connect() throws Exception {
		System.out.println("Client4.connect() 실행");
	}
	
	public void destroy() throws Exception {
		System.out.println("Client4.close() 실행");
	}
}
