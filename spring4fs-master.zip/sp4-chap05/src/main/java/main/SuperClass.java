package main;

public class SuperClass {
	public SuperClass(String name) {
		
	}
	
	
}
