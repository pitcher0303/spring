package main;

public class SubClass extends SuperClass {
	public SubClass() {
		super("name");
	}
}
