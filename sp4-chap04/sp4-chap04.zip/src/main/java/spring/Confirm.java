package spring;

public class Confirm {

}
