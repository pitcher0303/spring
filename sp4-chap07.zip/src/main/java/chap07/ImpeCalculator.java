package chap07;

public class ImpeCalculator implements Calculator {

	@Override
	public long factorial(long num) {
		System.out.println("calc value");
		long result = 1;
		for (long i = 1; i <= num; i++) {
			result *= i;
		}
		return result;
	}

	@Override
	public void printName() {
		// TODO Auto-generated method stub
		System.out.println("ImpeCalculator");
	}
}
