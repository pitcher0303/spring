package aspect;

import java.util.Arrays;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;

public class ExeTimeAspect {

	public Object measure2(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("measure invoked");
		long start = System.nanoTime();
		try {
			Object result = joinPoint.proceed();
			System.out.println("End meaure Proceed....");
			return result;
		} finally {
			long finish = System.nanoTime();
			Signature sig = joinPoint.getSignature();
			System.out.printf("%s.%s(%s) 실행 시간 : %d ns\n\n\n",
					joinPoint.getTarget().getClass().getSimpleName(),
					sig.getName(), Arrays.toString(joinPoint.getArgs()),
					(finish - start));
		}
	}
	
	public Object print(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("print invoked");
		System.out.println("The name is....");
		try {
			Object result = joinPoint.proceed();
			System.out.println("End print Proceed....");
			return result;
		} finally {
			System.out.print("Content:");
			Signature sig = joinPoint.getSignature();
			System.out.printf("%s.%s(%s) 이름 출력 \n\n",
					joinPoint.getTarget().getClass().getSimpleName(),
					sig.getName(), Arrays.toString(joinPoint.getArgs()));
		}
	}
}
